//importar a conectar db
import BD from "../config/db.js";
import { DataTypes } from "sequelize";

const productos= BD.define('productos', {

    nombre_producto: 
    {
        type: DataTypes.STRING,
        allowNull:false
    },
    cantidad: 
    {
        type: DataTypes.STRING,
        allowNull:false
    },
    direccion: 
    {
        type: DataTypes.STRING,
        allowNull:false
    },
    fecha: 
    {
        type: DataTypes.STRING,
        allowNull:false
    }

});

export default productos;

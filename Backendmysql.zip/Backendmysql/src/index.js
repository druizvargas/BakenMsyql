import express from "express";
import cors from "cors";
// importamos la configuracion de la BD
import BD from '../config/db.js';
// importamos el archivo de las rutas
import citasRoutes from '../routes/Routes_Citas.js'
import routes from '../routes/Routes_Productos.js'

// definimos la variable app para trabajar con express
const app = express();
app.use(cors());
app.use(express.json());
app.use('/citas', citasRoutes)
app.use('/productos', routes)

// autenticacion BD
try {
    await BD.authenticate();
    console.log('Connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }




// muestra mensaje en el navegador
app.get('/',(req,res) => {
    res.send("Hola mundo");
});

app.listen(5000, () => {
    console.log("El servidor esta corriendo en http://localhost:5000/");
});
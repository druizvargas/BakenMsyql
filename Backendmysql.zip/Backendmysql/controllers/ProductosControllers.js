// importar el modelo
import Productos from "../models/Productos.js"


// metodos crud



// crear una funcion para agregar productos

export const agregarProductos = async(req, res) =>{
    try {
        await Productos.create(req.body);
        res.json({ msg : " producto creado con exito"});
        
    } catch (error) {
        res.json ({ msg:error.mesagge});
        
    }
}


// funcion o metodo de mostrar  todas los productos

export const getAllProductos = async (req, res) => {
    try {
        const productos = await Productos.findAll();
        res.json(productos);
        
    } catch (error) {
        res.json({ msg: error.mesagge})
        
    }
}
// Funcion mostrar una producto
export const getProductos = async(req, res) =>{

    try {
        const productos = await Productos.findAll({
            where:{id:req.params.id}
        });
        res.json(productos[0]);
        
    } catch (error) {
        res.json({ msg: error.message})
        
    }
}
// modificar producto

export const modificarProductos = async (req, res) =>{

    try {
        await Productos.update(req.body, {
            where:{id: req.params.id}
        })
        res.json({ msg: "Se modifico el producto exitosamente"})

    } catch (error) {
        res.json({ msg : error.message})
    }
}

// eliminar producto

export const eliminarProductos = async (req, res) => {

    try {
        
       let productos =  await Productos.findAll({where:{ id: req.params.id}});
       if (!productos[0]){
        res.json({msg:"No se encontro el producto"});
       }
       await productos[0].destroy();
       res.json({msg:"se elimino el producto"})
        
    
        res.json({ msg: "se elimino un producto"})
    } catch (error) {
        res.json({msg: error.message})
    }
}
// importamos express
import express from 'express';
//importamos nuestro controlador

import { agregarProductos, eliminarProductos, getAllProductos, getProductos, modificarProductos } from '../controllers/ProductosControllers.js';


const router = express.Router();

router.post('/',agregarProductos)
router.get('/',getAllProductos);
router.get('/:id',getProductos);
router.put('/:id',modificarProductos);
router.delete('/:id',eliminarProductos);


export default router;
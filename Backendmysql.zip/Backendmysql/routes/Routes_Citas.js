// importar express 
import express from 'express';


// importamos nuestro controlador
import { agregarCitas,getAllCitas,getCita,modificarCita,eliminarCita } from '../controllers/CitasControllers.js';

import Citas from '../models/Citas.js';

const router = express.Router();
// rutas de los metodos crud
router.post('/',agregarCitas);
router.get('/',getAllCitas);
router.get('/:id',getCita);
router.put('/:id',modificarCita);
router.delete('/:id',eliminarCita);




export default router;





